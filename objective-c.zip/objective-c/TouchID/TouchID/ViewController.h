//
//  ViewController.h
//  TouchID
//
//  Created by James Harnett on 6/2/14.
//  Copyright (c) 2014 James Harnett. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *authentication;

- (IBAction)authenticationButton;


@end

